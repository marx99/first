
<div id="menu">
<ul>
<li><a href="index.php">index</a></li>
<li><a class="ks" href="detail.php">detail</a></li>
<li><a class="ks" href="input.php">input</a></li>
<li><a class="ks" href="list.php">list</a></li>
<li><a class="ks" href="master.php">master</a></li>
</ul>
</div>
<br/>
